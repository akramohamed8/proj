package engine;

public interface GameManager {
    
}
