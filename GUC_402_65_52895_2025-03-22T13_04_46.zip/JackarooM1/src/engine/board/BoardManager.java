package engine.board;

public interface BoardManager { 
    public int getSplitDistance();
}
